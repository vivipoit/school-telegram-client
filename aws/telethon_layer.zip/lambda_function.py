print('generic imports')

import os
import json

print('telethon imports')

from telethon import TelegramClient
from telethon.sync import TelegramClient
from telethon.sessions import StringSession
from telethon.tl.functions.messages import CreateChatRequest
from telethon.tl.functions.messages import ExportChatInviteRequest

print('function')

def lambda_handler(event, context):
    # print("Received event: " + json.dumps(event, indent=2))
    # print("Received context: " + json.dumps(context, indent=2))
    print("Received event: " + json.dumps(event, indent=2))
    
    body = json.loads(event['body'])
    
    string = os.environ.get('SESSION_STRING')
    api_id = os.environ.get('API_ID')
    api_hash = os.environ.get('API_HASH')
    
    print("environment: " + string + ", " + api_id + ", " + api_hash)
    
    
    with TelegramClient(StringSession(string), api_id, api_hash) as client:
        invited_users = client(CreateChatRequest([], 'test group'))
        chat = invited_users.updates.chats[0]
        print("chat: " + chat.stringify())
        chat_invite_exported = client(ExportChatInviteRequest(peer=chat, title="join-me"))
        print("chat_invite_exported: " + chat_invite_exported.link)

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({
            "course": body['course'],
            "invite_link": chat_invite_exported.link
        })
    }